"use strict";

//Toggle navigation

function openNav() {
   	document.getElementById('navigation').style.display = 'block';
  }
function closeNav() {
   	document.getElementById('navigation').style.display = 'none';
  }